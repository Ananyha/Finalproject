# CollaborationTools
An internship-based project designed to integrate multiple tools and platforms at the foundational level, ensuring seamless interoperability and efficient functionality across diverse systems.

# How to make this work?
First create a new Node Js Server and then install the dependencies.
```npm install express axios dotenv googleapis```
then create account on the platforms 
```Slack, Trello and Google Api Console Account```
Once you make these accounts all you need to do is provide the API Key and Tokens.


This is a Internship based project and not a complete and published Project.
